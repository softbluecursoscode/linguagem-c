// ProjetoEstruturaUnionTypedef.cpp : Defines the entry point for the console application.
//

#include "stdio.h"
#include "string.h"

struct estruturaPessoa 
{
	char nome[30];
	unsigned int idade;
	double peso;
} p1;

struct casal
{
	struct estruturaPessoa marido;
	struct estruturaPessoa esposa;
};

union minhaUnion
{
	int x;
	double y;
	char z[10];
};

struct meuStruct
{
	int x;
	double y;
	char z[10];
};

typedef struct estruturaPessoa pessoa;
typedef int inteiro;

void imprimePessoa(struct estruturaPessoa p)
{
	printf("\n %s tem %d anos e pesa %.2f kg. ", p.nome, p.idade, p.peso);
}

int main()
{
	char *c;

	struct estruturaPessoa p2;
	struct estruturaPessoa turma[50];
	struct estruturaPessoa *pe;
	struct casal namorados;
	pessoa p3;

	union minhaUnion mu;
	struct meuStruct ms;
	inteiro i;

	// Estruturas
	strcpy(p1.nome, "Joao");
	p1.idade = 30;
	p1.peso = 68.5;
	printf("\n %s tem %d anos e pesa %.2f kg. ", p1.nome, p1.idade, p1.peso);

	strcpy(turma[0].nome, "Maria");
	turma[0].idade = 31;
	turma[0].peso = 71;
	printf("\n %s tem %d anos e pesa %.2f kg. ", turma[0].nome, turma[0].idade, turma[0].peso);
	
	imprimePessoa(p1);
	imprimePessoa(turma[0]);

	pe = &p1;
	printf("\n Nome da pessoa via ponteiro: %s", pe->nome);

	namorados.marido = p1;
	namorados.esposa = turma[0];
	printf("\n %s e %s formam um casal.", namorados.marido.nome, namorados.esposa.nome);

	// Unions
	printf("\n Bytes ocupados por mu: %d", sizeof(mu));
	printf("\n Bytes ocupados por ms: %d", sizeof(ms));

	// Typedef
	printf("\n ");
	for(i=0; i<10; i++)
	{
		printf("%d ", i);
	}

	scanf("%c", &c);
	return 0;
}

