#include "stdio.h"
#include "string.h"

// Criando a estrutura
struct contas {
	char usuario[100];
	char senha[50];

};

int main()
{
	char *caractere;

	int x, quantidadeDeContas = 3;
	struct contas vetorDeContas[3];
	char tentativaUsuario[100], tentativaSenha[50];
	int autenticado;
	
	// Solicitando os nomes e as senhas
	for(x=0; x<quantidadeDeContas; x++) {
		printf("\nInsira os dados da conta #%d", x+1);
		
		printf("\nUsuario: ");
		gets(vetorDeContas[x].usuario);

		printf("Senha: ");
		gets(vetorDeContas[x].senha);
	}
	
	// Solicitando para o usuario tentar realizar uma autentica��o
	printf("\nInforme usuario para autenticar: ");
	gets(tentativaUsuario);

	printf("Informe senha para autenticar: ");
	gets(tentativaSenha);

	// Autenticando: se a vari�vel autenticado permanecer com 0 indica que n�o foi poss�vel autenticar a conta.
	autenticado = 0;
	
	for(x=0; x<quantidadeDeContas; x++) 
	{
		// Se a fun��o strcmp retornar 0, indica que as strings s�o iguais
	
		if(strcmp(vetorDeContas[x].usuario, tentativaUsuario) == 0 
			&& strcmp(vetorDeContas[x].senha, tentativaSenha) == 0) 
		{
			autenticado = 1;
			break;	// Break realizado pois � desnecess�rio continuar procurando a autentica��o uma vez j� realizada
		}
	}

	// Verifica se alguma autentica��o teve sucesso
	
	if(autenticado == 1) {
		printf("\nUsuario autenticado com sucesso!");
	}
	else {
		printf("\nUsuario ou senha incorreto.");
	}

	scanf("%c", &caractere);
	return 0;
}

