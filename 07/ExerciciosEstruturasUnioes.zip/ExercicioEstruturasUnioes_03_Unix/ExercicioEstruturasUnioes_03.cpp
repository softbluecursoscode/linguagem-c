#include "stdio.h"
#include "stdlib.h"

struct veiculo
{
	char modelo[100];
	char placa[10];
};

struct pessoa
{
	char nome[50];
	int numeroVeiculos;
	struct veiculo *veiculos;
};

int main()
{
	char *caractere;

	struct pessoa *pessoas;
	int numeroPessoas=0;
	int x, y;

	printf("Informe a quantidade de pessoas a serem cadastradas: ");
	scanf("%d", &numeroPessoas);
	scanf("%c", &caractere); // Limpa o buffer
	
	// Aloca dinamicamente o espaco necessario para armazenar "x" estruturas do tipo "pessoa"
	pessoas = (struct pessoa *) malloc(numeroPessoas * sizeof(struct pessoa));

	// Para cada estrutura (pessoa), solicita os dados
	for(x=0; x<numeroPessoas; x++)
	{
		printf("\nInforme o nome da pessoa #%d: ", x+1);
		gets(pessoas[x].nome);

		printf("Informe a quantidade de veiculos que '%s' possui: ", pessoas[x].nome);
		scanf("%d", &pessoas[x].numeroVeiculos);
		scanf("%c", &caractere); // Limpa o buffer

		// Aloca dinamicamente o espaco necessario para armazenar "x" estruturas do tipo "veiculo"
		pessoas[x].veiculos = (struct veiculo *) malloc(pessoas[x].numeroVeiculos * sizeof(struct veiculo));

		// Para cada estrutura (veiculo), solicita os dados
		for(y=0; y<pessoas[x].numeroVeiculos; y++)
		{
			printf("\nInforme o modelo do veiculo #%d da pessoa '%s': ", y+1, pessoas[x].nome);
			gets(pessoas[x].veiculos[y].modelo);

			printf("\nInforme a placa do veiculo #%d da pessoa '%s': ", y+1, pessoas[x].nome);
			gets(pessoas[x].veiculos[y].placa);
		}
	}

	// Exibe todas as estruturas "pessoa"
	for(x=0; x<numeroPessoas; x++)
	{
		// Exibe todas as estruturas "veiculo" da pessoa em questao
		for(y=0; y<pessoas[x].numeroVeiculos; y++)
		{
			printf("\nO veiculo %s de placa %s pertence a %s", pessoas[x].veiculos[y].modelo, pessoas[x].veiculos[y].placa, pessoas[x].nome);
		}
	}

	scanf("%c", &caractere);
	return 0;
}

