#include "stdio.h"

// Criando a estrutura
struct pessoa {
	char nome[100];
	int idade;

};

int main()
{
	char *caractere;

	int x, quantidadeDePessoas = 5;
	struct pessoa vetorDePessoas[5];
	struct pessoa maisJovem;
	char limparBuffer;
	
	// Solicitando os nomes e as idades de cada estrutura
	for(x=0; x<quantidadeDePessoas; x++) 
	{
		printf("\nInsira os dados da pessoa #%d", x+1);
		printf("\nNome: ");
		gets(vetorDePessoas[x].nome);
		
		printf("Idade: ");
		scanf("%d", &vetorDePessoas[x].idade);
		
		scanf("%c", &limparBuffer); // Instru��o ignorada, que apenas limpa o buffer de leitura
    }
	
	// Localizando o mais jovem
	maisJovem = vetorDePessoas[0];
	
	for(x=1; x<quantidadeDePessoas; x++) {
		if(vetorDePessoas[x].idade < maisJovem.idade) {
			maisJovem = vetorDePessoas[x];
		}
	}
	
	printf("\nO mais jovem chama-se: %s", maisJovem.nome);

	scanf("%c", &caractere);
	return 0;
}

