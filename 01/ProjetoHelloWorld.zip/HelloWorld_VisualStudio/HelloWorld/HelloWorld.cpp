#include "stdio.h"

int main()
{
	char *c;

	printf("Hello World");

	scanf("%c", &c);

}

