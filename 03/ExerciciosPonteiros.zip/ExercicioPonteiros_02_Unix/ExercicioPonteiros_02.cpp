#include "stdio.h"
#include "string.h"

void procuraLetraMaiuscula(int *varPosicao, char varVetor[])
{
	int x;
	for(x=0; x<strlen(varVetor); x++) 
	{
		if(65 <= varVetor[x] && varVetor[x] <= 90) 
		{
			*varPosicao = x;
			return;
		}		
	}
}

int main()
{
	char *caractere;

	char vetor[10] = {'f', 'g', 'e', 'H', 'd', 'w', 'N', 'd', 'l', 's'};
	int posicao;
	procuraLetraMaiuscula(&posicao, vetor);
	printf("Primeira letra maiuscula: %c", vetor[posicao]);
	printf("\nPosicao: %d", posicao);

	scanf("%c", &caractere);
	return 0;
}

