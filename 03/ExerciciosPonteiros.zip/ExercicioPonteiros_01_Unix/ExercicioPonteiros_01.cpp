// ExercicioPonteiros_01.cpp : Defines the entry point for the console application.
//

#include "stdio.h"

void trocaValores(int *varA, int *varB)
{
    int temp;

	// Armazena o valor contido em varA
    temp = *varA;

	// Passa para varA o valor contido em varB
    *varA = *varB;

	// Passa para varB o antigo valor de varA, guardado em "temp"
    *varB = temp;
}

int main()
{
	char *caractere;

	int x, y;
	x = 1;
	y = 2;
	
	// Exive os valores antes da troca
	printf("Valor de x:%d", x);
	printf("\nValor de y:%d", y);
	
	trocaValores(&x, &y);
	
	// Exibe os valores depois da troca
	printf("\n\nValor de x:%d", x);
	printf("\nValor de y:%d", y);

	scanf("%c", &caractere);
	return 0;
}

