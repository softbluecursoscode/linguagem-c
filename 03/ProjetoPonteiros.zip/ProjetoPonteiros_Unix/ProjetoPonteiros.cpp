#include "stdio.h"
#include "stdlib.h"

void somaUmNormal(int i)
{
	i = i + 1;
}

void somaUmPonteiro(int *i)
{
	*i = *i + 1;
}

int main()
{
	char *c;

	int a, b;
	int *pi = NULL;
	int **ppi = NULL;
	int *matrizInteiro;
	int matrizSemPonteiro[5] = {2, 4, 6, 8, 10};

	// Uso tradicional
	a = 5;
	b = a;
	printf("\n a = %d, b = %d", a, b);

	a = 5;
	b = a;
	a = 8;
	printf("\n a = %d, b = %d", a, b);

	a = b = 5;
	a = 8;
	printf("\n a = %d, b = %d", a, b);
	printf("\n a = %d (%d), b = %d (%d)", a, &a, b, &b);

	// Ponteiro
	a = 5;
	pi = &a;
	a = 8;
	printf("\n a = %d, pi = %d", a, pi);
	printf("\n a = %d, pi = %d", a, *pi);

	// Ponteiro para ponteiro
	a = 5;
	pi = &a;
	ppi = &pi;
	printf("\n a = %d, pi = %d, ppi = %d", a, *pi, ppi);
	printf("\n a = %d, pi = %d, ppi = %d", a, *pi, *ppi);
	printf("\n a = %d, pi = %d, ppi = %d", a, *pi, **ppi);

	// Passagem por valor
	a = 5;
	somaUmNormal(a);
	printf("\n Soma normal: a = %d", a);

	// Passagem por referencia
	a = 5;
	somaUmPonteiro(&a);
	printf("\n Soma normal: a = %d", a);

	// Alocacao dinamica de memoria
	matrizInteiro = (int *) malloc(5 * sizeof(int));

	if(!matrizInteiro)
	{
		printf("Erro");
	}

	matrizInteiro[0] = 5;
	matrizInteiro[1] = 10;
	printf("\n Posicao [0] = %d, posicao [1] = %d", matrizInteiro[0], matrizInteiro[1]);

	// Liberacao de memoria alocada dinamicamente
	free(matrizInteiro);

	// Aritmetica de ponteiro
	pi = &matrizSemPonteiro[0];
	printf("\n pi vale agora: %d", *pi);
	
	pi++;
	printf("\n pi vale agora: %d", *pi);

	pi = pi + 2;
	printf("\n pi vale agora: %d", *pi);
	
	pi--;
	printf("\n pi vale agora: %d", *pi);

	scanf("%c", &c);
	return 0;
}

