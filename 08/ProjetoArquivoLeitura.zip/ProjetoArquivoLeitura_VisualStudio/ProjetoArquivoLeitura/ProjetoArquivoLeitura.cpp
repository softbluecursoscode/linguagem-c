#include "stdio.h"
#include "string.h"

int main()
{
	char *c;

	char buffer[10] = "";
	char caractere;

	// Abre o arquivo em modo de leitura
	FILE *arquivo;
	arquivo = fopen("C:\\Users\\Milani\\Documents\\Visual Studio 2012\\Projects\\ProjetoArquivoEscrita\\Debug\\Registro.txt", "r");

	// Se o arquivo tiver sido aberto...
	if(arquivo != NULL)
	{
		// ...navega caractere por caractere ate o final do arquivo
		while( (caractere = getc(arquivo)) != EOF )
		{
			// Enquanto o buffer nao estiver cheio, carregue-o
			if(strlen(buffer) < 9)
			{
				sprintf(buffer, "%s%c", buffer, caractere);
			}
			else
			{
				// Ao estar cheio, exiba-o e depois limpe-o
				printf("%s", buffer);
				sprintf(buffer, "%c", caractere);
			}
		}

		// Caso tenha sobrado algum valor no buffer sem te-lo completado, exiba-o
		if(strlen(buffer) > 0)
		{
			printf("%s", buffer);
		}

		// Fecha o arquivo
		fclose(arquivo);
	}

	scanf("%c", &c);
	return 0;
}

