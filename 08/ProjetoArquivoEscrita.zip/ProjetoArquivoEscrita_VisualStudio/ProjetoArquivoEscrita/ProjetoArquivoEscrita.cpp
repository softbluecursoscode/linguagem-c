#include "stdio.h"
#include "string.h"

int main()
{
	char *c;

	FILE *arquivo;
	char string[100];
	int i;

	// Abre o arquivo em modo de gravacao
	arquivo = fopen("C:\\Users\\Milani\\Documents\\Visual Studio 2012\\Projects\\ProjetoArquivoEscrita\\Debug\\Registro.txt", "w");

	// Valida a abertura
	if(!arquivo)
	{
		printf("\n Arquivo inexistente");
		scanf("%c", &c);
		return 0;
	}

	// Captura uma informacao a ser gravada
	printf("\n Digite a informacao a ser registrada: ");
	gets(string);

	// Grava caractere a caractere
	for(i=0; i<strlen(string); i++)
	{
		putc(string[i], arquivo);
	}

	// Fecha o arquivo
	fclose(arquivo);

	scanf("%c", &c);
	return 0;
}

