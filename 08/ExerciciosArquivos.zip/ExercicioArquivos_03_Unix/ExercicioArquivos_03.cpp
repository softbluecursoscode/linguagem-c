#include "stdio.h"

struct pessoa
{
	char nome[50];
	int idade;
	char email[60];
};

int main()
{
	char *caractere;

	FILE *arquivo;
	struct pessoa p;
	int novosRegistros=0;
	int x;

	// Exibe registros j� existentes, abrindo o arquivo para leitura bin�ria
	arquivo = fopen("Dados.bin", "rb");

	if(arquivo != NULL)
	{
		// Realiza a leitura do tamanho da estrutura
		fread(&p, sizeof(p), 1, arquivo);
		do
		{
			printf("\n%s (%d anos): %s", p.nome, p.idade, p.email);
			fread(&p, sizeof(p), 1, arquivo);
		} while(!feof(arquivo));
	}

	fclose(arquivo);

	// Inserindo novos registros, abrindo o arquivo para escrita bin�ria

	printf("\nInforme quantos registros deseja criar: ");
	scanf("%d", &novosRegistros);
	scanf("%c", &caractere); // Limpa o buffer

	arquivo = fopen("Dados.bin", "ab");

	for(x=0; x<novosRegistros; x++)
	{
		printf("\nInforme o nome da pessoa #%d: ", x+1);
		gets(p.nome);

		printf("\nInforme a idade da pessoa #%d: ", x+1);
		scanf("%d", &p.idade);
		scanf("%c", &caractere); // Limpa o buffer

		printf("\nInforme o e-mail da pessoa #%d: ", x+1);
		gets(p.email);

		// Realiza a escrita, do tamanho de uma estrutura
		fwrite(&p, sizeof(p), 1, arquivo);
	}

	fclose(arquivo);

	scanf("%c", &caractere);
	return 0;
}

