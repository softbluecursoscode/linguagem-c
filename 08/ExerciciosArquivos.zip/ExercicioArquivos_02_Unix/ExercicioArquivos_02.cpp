#include "stdio.h"
#include "string.h"

void logarString(char stringLog[])
{
	FILE *arquivo;

	// Abre o arquivo de log no modo de escrita no final do arquivo
	arquivo = fopen("arquivoDeLog.txt", "a");

	// Grava a string a ser logada, caractere a caractere
	int x;
	for(x=0; x<strlen(stringLog); x++) 
	{
		putc(stringLog[x], arquivo); 
	}

	// Adiciona quebra de linha
	putc('\r', arquivo); 
	putc('\n', arquivo); 
	
	// Fecha o arquivo
	fclose(arquivo);
}

int main()
{
	char *caractere;

	logarString("Essa frase deve ser logada.");
	logarString("Outra informa��o para ser logada.");
	logarString("Novo log.");
	logarString("Logando uma nova informa��o.");

	scanf("%c", &caractere);
	return 0;
}
