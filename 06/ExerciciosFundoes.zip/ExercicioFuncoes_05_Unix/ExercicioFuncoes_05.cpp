#include "stdio.h"

int fibonacci(int i) 
{
	// Funcao recursiva que se auto-invoca ate a condicao i < 2 ser encontrada

	if(i < 2) 
	{
		return i;
	}
	else 
	{
		return fibonacci(i-1) + fibonacci(i-2);
	}
}

int main()
{
	char *caractere;

	int i;
	for(i=1; i<=10; i++) 
	{
		printf("%d ", fibonacci(i));
	}

	scanf("%c", &caractere);
	return 0;
}

