#include "stdio.h"

int somaDeIntervalo(int x, int y) 
{
	int i, resultado = 0;

	// Navega pelo intervalo de valores entre x e y, somando cada valor de forma acumulada
	for(i=x; i<=y; i++) 
	{
		resultado += i;
	}

	return resultado;
}

int main()
{
	char *caractere;

	int resultado = somaDeIntervalo(5, 10);
	printf("Soma do intervalo: %d", resultado);

	scanf("%c", &caractere);
	return 0;
}

