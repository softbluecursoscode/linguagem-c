#include "stdio.h"
#include "string.h"

void inverteString(char original[100], char invertida[100])
{
	int x;
	int y=0;
	
	// Navega pela string original de traz para frente
	// sem passar pela �ltima posi��o, pois ela n�o pode
	// ser a primeira da string invertida pois finaliza a mesma ('\0')
	for(x=strlen(original)-1; x>=0; x--)
	{
		invertida[y] = original[x];
		y++;
	}

	// Adiciona o final da string
	invertida[y] = '\0';
}

int main()
{
	char *caractere;

	char frase[100], invertida[100];

	// Captura a frase
	printf("Informe a frase: ");
	gets(frase);

	// Exibe o resultado
	inverteString(frase, invertida);
	printf("\n%s", invertida);

	scanf("%c", &caractere);
	return 0;
}

