#include "stdio.h"

// Vers�o para atender n�meros grandes utiliza "unsigned long long int"

unsigned long long int fatorial(unsigned long long int numero) 
{
	// Funcao recursiva que se auto-invoca ate que a condicao de numero == 1 ser encontrada

	if(numero == 1)
	{
		return 1;
	}
	else
	{
		return numero * fatorial(numero - 1);
	}
}

int main()
{
	char *caractere;

	unsigned long long int numero = 4;

	printf("%llu", fatorial(numero));

	scanf("%c", &caractere);
	return 0;
}

