#include "stdio.h"

float calculaMedia(float nota1, float nota2, float nota3, float peso1, float peso2, float peso3)
{
	// Declara uma variavel local para armazenar o resultado da operacao
	float resultado;

	// Realiza a conta
	resultado = ((nota1 / 10) * peso1) + ((nota2 / 10) * peso2) +((nota3 / 10) * peso3);

	// Retorna uma copia do resultado
	return resultado;
}

int main()
{
	char *caractere;

	float resultado = calculaMedia(10, 9, 8, 3, 2, 5);
	printf("Media: %f", resultado);

	scanf("%c", &caractere);
	return 0;
}
