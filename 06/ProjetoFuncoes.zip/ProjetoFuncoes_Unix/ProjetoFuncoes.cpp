#include "stdio.h"
#include "stdarg.h"

int somaValores(int valorA, int valorB)
{
		int resultado;
		resultado = valorA + valorB;
		return resultado;

		// return valorA + valorB;
}

void strBomdia(char *str, char *nome)
{
	sprintf(str, "Bom dia sr(a) %s", nome);
}

//void imprime(int *matriz)
//void imprime(int matriz[50])
void imprime(int matriz[], int tamanho)
{
	int x;

	printf("\n ");
	for(x=0; x<tamanho; x++)
	{
		printf("%d ", matriz[x]);
	}
}

int somaParametrosVariaveis(int p1, ...)
{
	int total = 0;
	int contadorDeParametros = 0;
	va_list args;
	int temp;

	va_start(args, numeroDeParametros);

	while (contadorDeParametros++ < numeroDeParametros)
	{
		temp = va_arg(args, int);
		total += temp;
	}

	return total;
}

int somaRecursao(int v)
{
	if(v == 1)
	{
		return 1;
	}
	else
	{
		return v + somaRecursao(v-1);
	}
}

int main(int argc, char *argv[])
{
	char *c;
	int i;
	char buffer[50];
	int valores[10] = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20};
	int (*ponteiroFuncao) (int a, ...);

	// Funcao simples
	i = somaValores(20, 30);
	printf("\n Resultado: %d", i);

	// Funcao por referencia
	strBomdia(buffer, "Andre");
	printf("\n %s", buffer);

	// Argumentos do metodo main
	for(i=0; i<argc; i++)
	{
		printf("\n Parametro %d: %s", i, argv[i]);
	}

	if(argc > 1)
	{
		strBomdia(buffer, argv[1]);
		printf("\n %s", buffer);
	}

	// Funcoes com matrizes
	imprime(valores, 10);

	// Parametros variaveis
	i = somaParametrosVariaveis(3, 3, 4, 5);
	printf("\n A soma e: %d", i);

	i = somaParametrosVariaveis(4, 3, 4, 5, 6);
	printf("\n A soma e: %d", i);

	i = somaParametrosVariaveis(5, 3, 4, 5, 6, 7);
	printf("\n A soma e: %d", i);

	// Ponteiro de funcao
	ponteiroFuncao = somaParametrosVariaveis;
	i = ponteiroFuncao(3, 4, 2, 3);
	printf("\n A soma e: %d", i);

	// Recursividade
	i = somaRecursao(5);
	printf("\n A soma recursao de 5 e: %d", i);

	scanf("%c", &c);
	return 0;
}

