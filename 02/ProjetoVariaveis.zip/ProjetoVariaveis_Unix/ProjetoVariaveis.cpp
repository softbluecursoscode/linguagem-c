// Uso de diretivas de compilacao

#include "stdio.h"

#define MINHA_DIR 4

#ifdef MINHA_DIR
	// ...
#endif

//#undef MINHA_DIR

#if MINHA_DIR == 3
	#define MINHA_DIR_2 2
#elif MINHA_DIR == 4
	#include "stdlib.h"
#else
	#define MINHA_DIR_3 3
#endif

// Variavel global
int meuIntGlobal;

void meuOutroMetodo()
{
	meuIntGlobal = meuIntGlobal + 1;
}

void meuMetodoEstatico()
{
	int static minhaVarEstatica = 10;

	minhaVarEstatica++;

	printf("%d ", minhaVarEstatica);
}

int main()
{
	char *c;

	int volatile meuInt = 10;
	double const meuDouble = 25.75;
	char meuChar = 'd';
	float meuFloat = 10.15;
	int a, b;
	int register minhaVarRegister;
	enum estacoes { verao, outono, inverno, primavera };
	enum estacoes minhaEstacao;

	printf("%d ", meuInt);
	printf("%f ", meuDouble);
	printf("%c ", meuChar);
	printf("%f \n", meuFloat);

	meuIntGlobal = 5;

	meuOutroMetodo();
	printf("%d \n", meuIntGlobal);

	a = b = 10;
	b = 15;
	printf("a: %d, b: %d \n", a, b);

	meuMetodoEstatico();
	meuMetodoEstatico();
	meuMetodoEstatico();

	minhaEstacao = verao;
	minhaEstacao = outono;
	if(minhaEstacao == verao) 
	{
		printf("calor \n");
	}

	a = 10;
	b = 3;

	a = 2 + 2 * (3 + 3);
	a += 10;
	a *= 2;
	a = (float) 48 / 5;
	printf("\n %d \n", a);

	meuFloat = (float) 48 / 5;
	printf("%f \n", meuFloat);

	meuFloat = 48;
	meuFloat = meuFloat / 5;
	printf("%f \n", meuFloat);

	meuFloat = 10;
	meuFloat *= MINHA_DIR;
	printf("%f \n", meuFloat);

	#line 5
	printf("\n Linha: %d do arquivo %s \n", __LINE__, __FILE__);

	//#error PROCEDIMENTO INACABADO (ANDRE MILANI)

	scanf("%c", &c);
	return 0;
}

