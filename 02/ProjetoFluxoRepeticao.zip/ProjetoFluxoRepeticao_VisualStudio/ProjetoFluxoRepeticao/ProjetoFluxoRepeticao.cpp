#include "stdio.h"

int main()
{
	char *c;
	int x = 5, y = 0;

	// Comandos IF, ELSE IF e ELSE
	x = 1;
	if(x >= 5)
	{
		printf("x vale 5 ou mais \n");
	}
	else if(x >= 3)
	{
		printf("x vale 3 ou mais \n");
	}
	else
	{
		printf("x nao vale mais que 3");
	}

	x = -50;
	y = x >= 0 ? 1 : -1; 
	printf("\n y vale %d \n", y);

	// Comandos SWITCH, CASE, BREAK e DEFAULT
	x = 3;
	switch(x)
	{
		case 1:
			printf("\n x vale 1 \n");
			break;
		case 2:
			printf("\n x vale 2 \n");
			break;
		case 3:
			printf("\n x vale 3 \n");
			break;
		default:
			printf("\n x nao foi identificado \n");
			break;
	}

	// Comandos FOR, BREAK e CONTINUE
	printf("\n");
	for(x=0; x<10; x++)
	{
		if(x == 8)
		{
			break;
		}

		if(x == 3)
		{
			continue;
		}

		printf("%d ", x);
	}
	printf("\n");

	x = 5;
	if(x == 10)
	{
		x = 15;
		x++;
	}
	printf("\n %d \n", x);

	// Comando WHILE
	printf("\n Comando While \n");
	x = 0;
	while(x < 10)
	{
		printf("%d ", x);
		x = x + 1;
	}
	printf("\n");

	// Comando DO WHILE
	printf("\n Comando Do While \n");
	x = 0;
	do
	{
		printf("%d ", x);
		x = x + 1;
	} while(x < 10);
	printf("\n");

	x = 2;
	y = 11;

	if(y == 11 && x++ == 5)
	{
		printf("\n Sucesso \n");
	}
	else
	{
		printf("\n Falha \n");
	}
	printf("X vale neste momento: %d \n", x);

	scanf("%c", &c);
	return 0;
}

