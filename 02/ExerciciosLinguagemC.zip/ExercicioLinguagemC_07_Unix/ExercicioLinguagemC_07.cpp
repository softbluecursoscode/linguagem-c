// ExercicioLinguagemC_07.cpp : Defines the entry point for the console application.
//

#include "stdio.h"

int main()
{
	char *caractere;

	int x, y;
	char operador;
	float resultado;
	
	// Solicita os dados
	printf("Informe o primeiro numero: ");
	scanf("%d", &x);
	
	printf("Informe o segundo numero: ");
	scanf("%d", &y);
	
	printf("Informe o operador (+*-/): ");
	scanf("%c", &operador);	// Limpa o buffer de leitura das operacoes anteriores
	scanf("%c", &operador);
	
	switch(operador) 
	{
		case '+':
			resultado = x + y;
			break;
		case '-':
			resultado = x - y;
			break;
		case '*':
			resultado = x * y;
			break;
		case '/':
			resultado = x / y;
			break;
	}
	
	printf("Resultado: %f", resultado);
	
	scanf("%c", &caractere);
	scanf("%c", &caractere);
	return 0;
}

