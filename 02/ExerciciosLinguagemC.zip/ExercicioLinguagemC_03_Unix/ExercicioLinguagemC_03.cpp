#include "stdio.h"

int main()
{
	char *caractere;

	int x;
	
	printf("Digite um valor: ");
	scanf("%d", &x);
	scanf("%c", &caractere); // Limpa o buffer

	if(x % 2 == 0) 
	{
		printf("Par");
	}
	else 
	{
		printf("Impar");
	}
	
	scanf("%c", &caractere);
	return 0;
}

