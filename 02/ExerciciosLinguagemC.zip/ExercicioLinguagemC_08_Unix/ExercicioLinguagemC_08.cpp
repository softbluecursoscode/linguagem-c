#include "stdio.h"

int main()
{
	char *caractere;

	int x = 13;
	int y = 0;
	
	while(y != 1) 
	{
		if(x % 2 == 0) 
		{
			y = x / 2;
		}
		else 
		{
			y = 3 * x + 1;
		}
		
		printf("%d ", y);
		x = y;
	}
	
	scanf("%c", &caractere);
	return 0;
}

