#include "stdio.h"

int main()
{
	char *caractere;

	int x;
	for(x=1; x<=100; x++) 
	{
		printf("%d \n", x);
	}

	scanf("%c", &caractere);
	return 0;
}

