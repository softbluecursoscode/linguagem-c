// ExercicioLinguagemC_05.cpp : Defines the entry point for the console application.
//

#include "stdio.h"

int main()
{
	char *caractere;

	int segundos;
	int minutos = 0;
	int horas = 0;
		
	// Solicita os dados
	printf("Insira uma quantidade de segundos: ");
	scanf("%d", &segundos);	
	scanf("%c", &caractere); // Limpa o buffer
	
	// Calcula quantas horas inteiras podem ser subtra�das do total de segundos
	while(segundos > 3600) 
	{
		segundos -= 3600;
		horas++;
	}
	
	// Dos segundos restantes, calcula os minutos inteiros que podem ser obtidos
	while(segundos > 60) 
	{
		segundos -= 60;
		minutos++;
	}
	
	printf("%d horas, %d minutos e %d segundos \n", horas, minutos, segundos);

	scanf("%c", &caractere);
	return 0;
}

