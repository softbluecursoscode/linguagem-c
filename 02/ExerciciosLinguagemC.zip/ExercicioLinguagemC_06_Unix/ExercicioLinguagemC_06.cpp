#include "stdio.h"

int main()
{
	char *caractere;

	int x, y, z, maior, menor;
	float media;
	
	// Solicita os n�meros
	printf("Informe o primeiro numero: ");
	scanf("%d", &x);
	
	printf("Informe o segundo numero: ");
	scanf("%d", &y);
	
	printf("Informe o terceiro numero: ");
	scanf("%d", &z);
	
	// Procurando o maior n�mero
	if(x > y && x > z) 
	{
		maior = x;
	} 
	else if(y > x && y > z) 
	{
		maior = y;
	}
	else 
	{
		maior = z;
	}
	
	// Procurando o menor n�mero
	if(x < y && x < z) 
	{
		menor = x;
	} 
	else if(y < x && y < z) 
	{
		menor = y;
	}
	else {
		menor = z;
	}
	
	// Calculando a m�dia
	media = (x + y + z) / 3.0;
	
	printf("Maior numero: %d \n", maior);
	printf("Menor numero: %d \n", menor);
	printf("Media: %f \n", media);
	
	scanf("%c", &caractere); // Limpa o buffer
	scanf("%c", &caractere);
	return 0;
}

