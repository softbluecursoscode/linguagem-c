#include "stdio.h"

int main()
{
	char *caractere;

	int x;
	int soma = 0;
	
	for(x=50; x<=100; x=x+2) 
	{
		soma += x;
	}
	
	printf("Total: %d", soma);

	scanf("%c", &caractere);
	return 0;
}

