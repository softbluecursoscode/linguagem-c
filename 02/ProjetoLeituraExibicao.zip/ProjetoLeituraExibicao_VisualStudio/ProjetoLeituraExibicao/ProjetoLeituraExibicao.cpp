#include "stdio.h"
#include "time.h"

int main()
{
	char *c;
	int varInt = 70;
	double varDouble = 150.15;
	float varFloat;
	char varChar;
	int y = 50, z = 100;
	char buffer[100];

	// Manipulando datas
	time_t agora;
	struct tm *tm_agora;
	char texto[100];

	// Caracteres de formatacao
	printf("\n Valor de varInt (inteiro): %d", varInt);
	printf("\n Valor de varInt (hexadecimal): %x", varInt);
	printf("\n Valor de varInt (octal): %o", varInt);
	printf("\n Valor de varInt (flutuante): %f", varInt);
	printf("\n Valor de varInt (caractere): %c", varInt);
	printf("\n Valor de varDouble (flutuante): %f", varDouble);
	printf("\n A soma de %d com %d resulta em %d", y, z, y+z);
	
	printf("\n %5.5f", 123.456789);
	printf("\n %15.5f", 123.456789);
	printf("\n %15.2f", 123.456789);
	
	printf("\n %3.5d", 123);
	printf("\n %3.3d", 123);
	printf("\n %10.3d", 123);
	printf("\n %10.5d", 123);
	
	printf("\n %20.25s", "Minha string");
	printf("\n %5.10s", "Minha string");

	// Capturando valores
	printf("\n Insira um valor inteiro: ");
	scanf("%d", &varInt);
	scanf("%c", &c);
	printf("\n O valor digitado foi: %d", varInt);

	printf("\n Insira um valor float: ");
	scanf("%f", &varFloat);
	scanf("%c", &c);
	printf("\n O valor digitado foi: %f", varFloat);

	printf("\n Insira um valor double: ");
	scanf("%lf", &varDouble);
	scanf("%c", &c);
	printf("\n O valor digitado foi: %f", varDouble);

	printf("\n Insira um valor char: ");
	scanf("%c", &varChar);
	scanf("%c", &c);
	printf("\n O valor digitado foi: %c", varChar);

	// Manipulando datas
	agora = time(NULL);
	tm_agora = localtime(&agora);
	strftime(texto, sizeof(texto), "%d/%m/%y", tm_agora);
	printf("\n A data de hoje e: %s", texto);

	sprintf(buffer, "A data de hoje e: %s", texto);
	printf("\n A variavel buffer contem: %s", buffer);

	scanf("%c", &c);
	return 0;
}

