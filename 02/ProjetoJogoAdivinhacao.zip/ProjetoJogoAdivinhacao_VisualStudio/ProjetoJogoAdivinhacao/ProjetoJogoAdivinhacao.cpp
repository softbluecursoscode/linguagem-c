#include "stdio.h"
#include "stdlib.h"
#include "time.h"

int main()
{
	char *c;
	int numeroSecreto, tentativa;

	// Randomiza o numero a ser adivinhado
	srand(time(NULL));
	numeroSecreto = rand() % 20 + 1;

	do
	{
		// Captura as tentativas do usuario
		printf("\n Adivinhe o numero (entre 1 e 20): ");
		scanf("%d", &tentativa);
		scanf("%c", &c); // Limpa o buffer

		// Avalia se o usuario digitou algo menor ou maior
		if(numeroSecreto < tentativa)
		{
			printf("\n O numero e menor.");
		}
		else if(numeroSecreto > tentativa)
		{
			printf("\n O numero e maior.");
		}

	} while(numeroSecreto != tentativa);

	printf("\n Acertou, o numero era: %d", numeroSecreto);
	printf("\n Pressione <ENTER> para sair...");

	scanf("%c", &c);
	return 0;
}

