#include "stdio.h"
#include "string.h"
#include "stdlib.h"

int main()
{
	char *c;

	// Declarando strings
	char strA[6] = "teste";
	char strB[6] = {'t', 'e', 's', 't', 'e'};
	char strC[] = "teste";
	char *strD;
	char matrizDeStrings[3][20];
	int x;
	char buffer[50];
	char *resultado;
	char ascii;
	char minhaStringInt[3] = "50";
	char minhaStringDouble[4] = "2.3";
	double y;

	strD = "teste";
	
	printf("\n %s", strA);
	printf("\n %s", strB);
	printf("\n %s", strC);
	printf("\n %s", strD);

	// Comandos gets e puts
	printf("\n Digite uma string: ");
	gets(strA);
	puts(strA);
	
	puts("1");
	puts("2");
	puts("3");
	puts("4\n5");

	// Matriz de strings
	puts("Matriz de strings");

	for(x=0; x<3; x++)
	{
		sprintf(buffer, "\n Digite o nome %d: ", x);
		puts(buffer);
		gets(matrizDeStrings[x]);
	}

	puts("Os nomes digitados foram:");
	for(x=0; x<3; x++)
	{
		puts(matrizDeStrings[x]);
	}

	// Outras funcoes para strings
	puts("Funcoes interessantes");

	strcpy(buffer, "Novo valor");
	puts(buffer);

	strcat(buffer, " concatenado");
	puts(buffer);

	x = strlen(buffer);
	sprintf(buffer, "O tamanho do buffer era: %d", x);
	puts(buffer);

	if(!strcmp(matrizDeStrings[0], buffer))
	{
		puts("Iguais");
	}
	else
	{
		puts("Diferentes");
	}
	
	strcpy(matrizDeStrings[0], "Softblue");
	strcpy(buffer, "Softblue");

	if(!strcmp(matrizDeStrings[0], buffer))
	{
		puts("Iguais");
	}
	else
	{
		puts("Diferentes");
	}

	// Localizacao
	strcpy(buffer, "Minha string de teste");
	
	resultado = strchr(buffer, 'i');
	puts(resultado);

	resultado = strrchr(buffer, 'i');
	puts(resultado);

	resultado = strstr(buffer, "string");
	puts(resultado);

	// Codigos Ascii
	ascii = 'A';
	printf("\n Caracter e seu codigo ascci: %c (%d)", ascii, ascii);

	ascii = 66;
	printf("\n Caracter e seu codigo ascci: %c (%d)", ascii, ascii);

	// Caracteres de escape
	printf("\n Curso de \"C\" ");
	printf("\n Beep \a");
	printf("\n Tabulacao\tUso do barra \\\" ");

	x = atoi(minhaStringInt);
	printf("\n A soma de %d com 10 resulta em: %d", x, x+10);

	y = atof(minhaStringDouble);
	printf("\n O dobro de %f e: %f", y, y*2);

	scanf("%c", &c);
	return 0;
}

