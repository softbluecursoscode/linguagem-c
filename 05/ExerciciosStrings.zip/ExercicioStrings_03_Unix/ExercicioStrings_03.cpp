#include "stdio.h"
#include "string.h"

int main()
{
	char *caractere;

	char frase[1000];
	int x;
	
	printf("Digite a frase: ");
	gets(frase);
	
	// Navega pela string informada
	for(x=0; x<strlen(frase); x++) 
	{
		// Exibe somente os caracteres cujo valor ASCII represente uma vogal (mai�scula ou min�scula)
		if(frase[x] == 65 || frase[x] == 69 || frase[x] == 73 || frase[x] == 79 || frase[x] == 85 || 
			frase[x] == 97 || frase[x] == 101 || frase[x] == 105 || frase[x] == 111 || frase[x] == 117) 
		{
			printf("%c", frase[x]);
		}
	}

	scanf("%c", &caractere);
	return 0;
}

