#include "stdio.h"
#include "string.h"

int main()
{
	char *caractere;

	char frase[1000];
	char subfrase[1000];
	int quantidade = 0;
	int x;
	int y;
	
	// Captura as strings utilizadas pelo exercicio
	printf("Digite a frase principal: ");
	gets(frase);
	
	printf("Digite a frase a ser procurada: ");
	gets(subfrase);

	// Procura manualmente a segunda string dentro da primeira
	for(x=0; x<strlen(frase); x++) 
	{
		// Realiza a compara��o a partir do caracter x em diante
		y = 0;
		while(frase[x+y] == subfrase[y]) 
		{
			// Se o caracter atual for igual, continua a comparar os pr�ximos
			y++;
			
			// Se chegou ao fim da subfrase, indica que a ocorr�ncia foi encontrada
			if(strlen(subfrase) == y) 
			{
				quantidade++;	// Atualiza o n�mero de ocorr�ncias
				break;			// Encerra o loop de compara��o while
			}
		}
	}
	
	printf("Subfrase encontrada %d vezes.", quantidade);

	scanf("%c", &caractere);
	return 0;
}

