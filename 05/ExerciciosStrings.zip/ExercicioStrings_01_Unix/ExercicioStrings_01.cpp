#include "stdio.h"
#include "string.h"

int main()
{
	char *caractere;

	char nome[100];
	int x;

	// Captura o nome
	printf("Informe um nome completo: ");
	gets(nome);
	
	// Avalia o tamanho do nome
	if(strlen(nome) <= 30) 
	{
		printf("Nome com menos de 30 caracteres: %d caracteres.\n", strlen(nome));
	}
	else 
	{
		printf("Nome com mais de 30 caracteres: %d caracteres.\n", strlen(nome));
	}
	
	// Navega pelo nome informado, em um laco de repeticao que corre de tras para frente
	for(x=strlen(nome)-1; x>=0; x--) 
	{
		printf("%c", nome[x]);
	}

	scanf("%c", &caractere);
	return 0;
}

