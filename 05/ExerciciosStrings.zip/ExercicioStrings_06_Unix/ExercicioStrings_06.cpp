// ExercicioStrings_06.cpp : Defines the entry point for the console application.
//

#include "stdio.h"
#include "string.h"

int main()
{
	char *caractere;

	char texto[100], invertido[100];
	int x;
	int y=0;

	// Captura a string do exercicio
	printf("Informe a string: ");
	gets(texto);

	// Navega pela string original de traz para frente
	// sem passar pela �ltima posi��o, pois ela n�o pode
	// ser a primeira da string invertida pois finaliza a mesma ('\0')
	for(x=strlen(texto)-1; x>=0; x--)
	{
		invertido[y] = texto[x];
		y++;
	}

	// Adiciona o final da string
	invertido[y] = '\0';

	// Exibe o resultado
	printf("\nString invertida: %s", invertido);

	scanf("%c", &caractere);
	return 0;
}

