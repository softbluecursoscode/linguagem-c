#include "stdio.h"
#include "string.h"

int main()
{
	char *caractere;

	char frase[1000];
	char fraseCapitalizada[1000];
	
	printf("Informe uma frase: ");
	gets(frase);
	
	// Caracteres min�sculos tem seus valores ASCII entre 97 e 122
	// 32 � a diferen�a ASCII entre o correspondente min�sculo e mai�sculo de um caracter (consulte tabela ASCII)
	// 32 � tamb�m o valor ASCII do espa�o em branco
	
	// Tratando o primeiro caracter
	if(97 <= frase[0] && frase[0] <= 122) 
	{
		fraseCapitalizada[0] = (char) (frase[0] - 32);
	}
	else 
	{
		fraseCapitalizada[0] = frase[0];
	}
	
	// Tratando do segundo ao �ltimo caracter
	int x;
	for(x=1; x<=strlen(frase); x++) 
	{
	
		// Se o caracter anterior for um espa�o em branco, ent�o capitalize se necess�rio
		if (frase[x-1] == 32) 
		{
			if(97 <= frase[x] && frase[x] <= 122) 
			{
				fraseCapitalizada[x] = (char) (frase[x] - 32);
			}
			else 
			{
				fraseCapitalizada[x] = frase[x];
			}
		}
		
		// Se o caracter anterior n�o for espa�o em branco, copie como est�
		else 
		{
			fraseCapitalizada[x] = frase[x];
		}
	}
	
	printf("Frase capitalizada:\n%s", fraseCapitalizada);

	scanf("%c", &caractere);
	return 0;
}

