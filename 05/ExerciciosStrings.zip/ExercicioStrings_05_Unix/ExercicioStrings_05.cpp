#include "stdio.h"
#include "string.h"

int main()
{
	char *caractere;

	char frase[1000];
	int x;
	int y;
	char caracterAtual;
	char caracterComparado;
	char caracterTemp;
	
	// Captura a string do exercicio
	printf("Digite a frase: ");
	gets(frase);

	// Comparar cada caracter com os pr�ximos que aparecem na string
	for(x=0; x<strlen(frase)-1; x++) 
	{
		for(y=x+1; y<strlen(frase); y++) 
		{
			// Para facilitar a compara��o entre min�sculos e mai�sculos, convert�-los para o mesmo formato.
			// Adotei o mai�sculo como padr�o tempor�rio para compara��o.
			
			// Padroniza o caracter atual em uma vari�vel tempor�ria
			if(97 <= frase[x] && frase[x] <= 122) 
			{
				caracterAtual = (char) (frase[x] - 32);
			}
			else 
			{
				caracterAtual = frase[x];
			}
			
			// Padroniza o caracter a ser comparado, tamb�m em uma vari�vel tempor�ria
			if(97 <= frase[y] && frase[y] <= 122) 
			{
				caracterComparado = (char) (frase[y] - 32);
			}
			else 
			{
				caracterComparado = frase[y];
			}
			
			// Troca suas posi��es originais somente se o primeiro for maior que o segundo
			if(caracterAtual > caracterComparado) 
			{
				caracterTemp = frase[x];
				frase[x] = frase[y];
				frase[y] = caracterTemp;
			}
		}
	}
	
	printf("Frase ordenada: %s", frase);

	scanf("%c", &caractere);
	return 0;
}

