#include "stdio.h"
#include "stdlib.h"

int main()
{
	char *c;

	// Ponteiro para matriz de uma dimensao
	int *matrizUnidimensional;

	// Ponteiro para ponteiro (matriz de duas posicoes)
	int **matrizBidimensional;
	int x, y;

	// Alocacao de uma dimensao
	matrizUnidimensional = (int *) malloc(5 * sizeof(int));
	
	matrizUnidimensional[0] = 15;
	matrizUnidimensional[1] = 25;
	matrizUnidimensional[2] = 35;
	matrizUnidimensional[3] = 45;
	matrizUnidimensional[4] = 55;

	for(x=0; x<5; x++)
	{
		printf("\n Matriz unidimensional [%d] = %d", x, matrizUnidimensional[x]);
	}

	// Liberacao de uma dimensao
	free(matrizUnidimensional);

	// Alocacao de duas dimensoes (passo 1/2: dimensao 1)
	matrizBidimensional = (int **) malloc(5 * sizeof(int *));
	
	// Alocacao de duas dimensoes (passo 2/2: dimensao 2 para cada item da dimensao 1)
	matrizBidimensional[0] = (int *) malloc(2 * sizeof(int));
	matrizBidimensional[1] = (int *) malloc(2 * sizeof(int));
	matrizBidimensional[2] = (int *) malloc(2 * sizeof(int));
	matrizBidimensional[3] = (int *) malloc(2 * sizeof(int));
	matrizBidimensional[4] = (int *) malloc(2 * sizeof(int));
	
	matrizBidimensional[0][0] = 1;
	matrizBidimensional[0][1] = 2;
	matrizBidimensional[1][0] = 3;
	matrizBidimensional[1][1] = 4;
	matrizBidimensional[2][0] = 5;
	matrizBidimensional[2][1] = 6;
	matrizBidimensional[3][0] = 7;
	matrizBidimensional[3][1] = 8;
	matrizBidimensional[4][0] = 9;
	matrizBidimensional[4][1] = 10;

	for(x=0; x<5; x++)
	{
		for(y=0; y<2; y++)
		{
			printf("\n Matriz bidimensional [%d][%d]: %d", x, y, matrizBidimensional[x][y]);
		}
	}

	// Liberando matriz de duas dimensoes: primeiro libera todas as posicoes da segunda dimensao
	for(x=0; x<5; x++)
	{
		free(matrizBidimensional[x]);
	}

	// Por ultimo, libera a primeira dimensao
	free(matrizBidimensional);

	scanf("%c", &c);
	return 0;
}

