#include "stdio.h"
#include "stdlib.h"

int main()
{
	char *caractere;
	int n;
	int *vetor; 
	int x;
	int soma = 0;

	// Captura o tamanho da matriz a ser criada
	printf("Entre com o tamanho do vetor: ");
	scanf("%d", &n);

	// Aloca dinamicamente a matriz
	vetor = (int *) malloc (n * sizeof(int));
	
	// Captura o valor de cada posicao da matriz
	for(x=0; x<n; x++) 
	{
		printf("Entre com o valor do elemento #%d:", x+1);
		scanf("%d", &vetor[x]);
	}
	
	// Soma cada posicao da matriz
	for(x=0; x<n; x++) 
	{
		soma += vetor[x];
	}

	// Exibe na tela o resultado
	printf("Total da soma dos elementos: %d", soma);

	free(vetor);	// Liberando a mem�ria
	vetor = NULL;	// Liberando o ponteiro
	
	scanf("%c", &caractere); // Limpa o buffer
	scanf("%c", &caractere);
	return 0;
}

