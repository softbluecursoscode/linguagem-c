#include "stdio.h"

int main()
{
	char *caractere;

	int vetor[5];
	int tamanhoVetor = 5;
	
	int menorValor, maiorValor;
	float media;
	
	int x;
	
	// Solicitar os 5 elementos do vetor ao usu�rio
	for(x=0; x<tamanhoVetor; x++) {

		// Exibindo ao usu�rio a numera��o de 1 a 5 (por isso o x+1)
		printf("Insira o elemento #%d:", x+1);
		
		// Lendo as posi��o de 0 a 4 do vetor (vetor inicia na posi��o 0)
		scanf("%d", &vetor[x]);
	}
	
	menorValor = vetor[0];
	maiorValor = vetor[0];
	media = vetor[0];
	
	// Buscando os valores solicitados
	for(x=0; x<tamanhoVetor; x++) {
			
		// Buscando ou atualizando menor valor
		if(vetor[x] < menorValor) {
			menorValor = vetor[x];
		}
		
		// Buscando ou atualizando maior valor
		if(vetor[x] > maiorValor) {
			maiorValor = vetor[x];
		}
		
		// Calculando a m�dia
		media = (media + vetor[x]) / 2;
	}
	
	// Exibindo os resultados
	printf("Menor valor: %d \n", menorValor);
	printf("Maior valor: %d \n", maiorValor);
	printf("Media: %f ", media);
	
	scanf("%c", &caractere); // Limpa o buffer
	scanf("%c", &caractere);
	return 0;
}

