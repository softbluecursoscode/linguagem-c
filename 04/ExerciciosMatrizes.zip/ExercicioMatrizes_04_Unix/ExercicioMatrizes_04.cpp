#include "stdio.h"

int main()
{
	char *caractere;

	int linhas = 2, colunas = 2, matrizA[2][2], matrizB[2][2], matrizResultado[2][2];
	int x, y;
	
	// Capturando a matriz A
	printf("Dados da matriz A:\n");
	for(x=0; x<linhas; x++) {
		for(y=0; y<colunas; y++) {
			printf("Insira o elemento %dx%d: ", x+1, y+1);
			scanf("%d", &matrizA[x][y]);
		}
	}
	
	// Capturando a matriz B
	printf("\n Dados da matriz B:\n");
	for(x=0; x<linhas; x++) {
		for(y=0; y<colunas; y++) {
			printf("Insira o elemento %dx%d: ", x+1, y+1);
			scanf("%d", &matrizB[x][y]);
		}
	}
	
	// Somando as matrizes e armazenando em uma terceira matriz (matrizResultado)
	for(x=0; x<linhas; x++) {
		for(y=0; y<colunas; y++) {
			matrizResultado[x][y] = matrizA[x][y] + matrizB[x][y];
		}
	}
	
	// Apresentando na tela o resultado
	printf("\n Matriz resultado:\n");
	for(x=0; x<linhas; x++) {
		for(y=0; y<colunas; y++) {
			printf("%d ", matrizResultado[x][y]);
		}
		printf("\n");
	}
	
	scanf("%c", &caractere); // Limpa o buffer
	scanf("%c", &caractere);
	return 0;
}

