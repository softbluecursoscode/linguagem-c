#include "stdio.h"
#include "stdlib.h"

int main()
{
	char *caractere;
	int l;
	int c;
	int **matriz;	// Dois asteriscos pois a matriz ser� de duas dimens�es 
	int x, y;

	// Captura os dados que irao formar a matriz
	printf("Entre com o a quantidade de linhas da matriz: ");
	scanf("%d", &l);
	
	printf("Entre com o a quantidade de colunas da matriz: ");
	scanf("%d", &c);
	
	// Alocando ponteiros (das colunas) para o n�mero de linhas informado
	matriz = (int **) malloc (l * sizeof(int *));
	
	// Para cada linha, alocar o n�mero de colunas informado
	for(x=0; x<l; x++) {
		matriz[x] = (int *) malloc (c * sizeof(int));
	}
	
	// Captura os elementos da matriz
	printf("\nInserindo os elementos: \n");
	for(x=0; x<l; x++) 
	{
		for(y=0; y<c; y++) 
		{
			printf("Insira o elemento da posicao %d,%d: ", x, y);
			scanf("%d", &matriz[x][y]);
		}
	}
	
	// Exibe a matriz original, e a transposta em seguida
	printf("\nMatriz original: \n");
	for(x=0; x<l; x++) 
	{
		for(y=0; y<c; y++) 
		{
			printf("%d ", matriz[x][y]);
		}
		printf("\n");
	}
	
	printf("\nMatriz transposta: \n");
	for(y=0; y<c; y++) 
	{
		for(x=0; x<l; x++) 
		{
			printf("%d ", matriz[x][y]);
		}
		printf("\n");
	}
		
	// Liberando a mem�ria (cada coluna, segunda dimens�o)
	for(x=0; x<l; x++) 
	{
		free(matriz[x]);
	}
	
	// Libera o ponteiro que gerenciava as linhas (primeira dimens�o)
	free(matriz);
	matriz = NULL;
	
	scanf("%c", &caractere); // Limpa o buffer
	scanf("%c", &caractere);
	return 0;
}

