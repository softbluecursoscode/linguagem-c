// ExercicioMatrizes_03.cpp : Defines the entry point for the console application.
//

#include "stdio.h"

int main()
{
	char *caractere;

	int linhas = 3, colunas = 4, matriz[3][4];
	int x, y;
	
	// Captura os elementos da matriz
	for(x=0; x<linhas; x++) {
		for(y=0; y<colunas; y++) {
			printf("Insira o elemento %dx%d: ", x+1, y+1);
			scanf("%d", &matriz[x][y]);
		}
	}
	
	// Exibe a matriz original, e depois a transposta
	printf("\nMatriz original: \n");
	for(x=0; x<linhas; x++) {
		for(y=0; y<colunas; y++) {
			printf("%d ", matriz[x][y]);
		}
		printf("\n");
	}
	
	printf("\nMatriz transposta: \n");
	for(y=0; y<colunas; y++) {
		for(x=0; x<linhas; x++) {
			printf("%d ", matriz[x][y]);
		}
		printf("\n");
	}
	
	scanf("%c", &caractere); // Limpa o buffer
	scanf("%c", &caractere);
	return 0;
}

