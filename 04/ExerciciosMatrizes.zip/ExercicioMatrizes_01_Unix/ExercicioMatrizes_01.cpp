#include "stdio.h"

int main()
{
	char *caractere;

	int vetor[] = {2, 7, 4, 6, 12, 32, 45, 12, 34};
	int tamanhoVetor = 9;
	
	int x;
	int y;
	int temp;

	// Algoritmo de ordena��o: para cada posi��o, compara com todas as adiante
	// trazendo o menor valor apresentado da posi��o atual pra frente para esta posi��o

	for(x=0; x<tamanhoVetor-1; x++) 
	{
		for(y=x+1; y<tamanhoVetor; y++) 
		{
			// Se for menor que o comparado, troca seus lugares
			if(vetor[x] > vetor[y]) 
			{
				temp = vetor[x];
				vetor[x] = vetor[y];
				vetor[y] = temp;
			}
		}
	}
	
	// Exibe o resultado na tela
	for(x=0; x<tamanhoVetor; x++) 
	{
		printf("%d ", vetor[x]);
	}

	scanf("%c", &caractere);
	return 0;
}

