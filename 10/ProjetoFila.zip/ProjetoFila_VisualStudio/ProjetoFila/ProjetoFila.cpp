// ProjetoFila.cpp : Defines the entry point for the console application.
//

#include "stdio.h"

#define CAPACIDADE 5

struct elemento
{
	int valor;
};

int indiceInsercao = 0;
int indiceRemocao = 0;

struct elemento fila[CAPACIDADE];

// Enfileira um elemento
void enqueue(struct elemento e)
{
	if(indiceInsercao >= CAPACIDADE)
	{
		printf("\n Estrutura de dados sem vaga para o elemento.");
	}
	else
	{
		fila[indiceInsercao] = e;
		indiceInsercao++;
	}
}

// Verifica se a fila esta vazia
int filaEstaVazia()
{
	if(indiceRemocao >= indiceInsercao)
		return 1;
	else
		return 0;
}

// Desenfileira um elemento
struct elemento dequeue()
{
	if(!filaEstaVazia())
	{
		return fila[indiceRemocao++];
	}
}

// Imprime a fila
void imprimeFila()
{
	int x;

	if(filaEstaVazia())
		printf("\n Estrutura de dados vazia.");
	else
	{
		printf("\n ");
		for(x=indiceRemocao; x<indiceInsercao; x++)
		{
			printf("%d ", fila[x].valor);
		}
	}
}

// Simula o atendimento de um elemento
void atende(struct elemento e)
{
	printf("\n Atendendo elemento %d.", e.valor);
}

int main()
{
	char *c;

	struct elemento e1, e2, e3, e4, e5, e6, temp;
	
	e1.valor = 1;
	e2.valor = 2;
	e3.valor = 3;
	e4.valor = 4;
	e5.valor = 5;
	e6.valor = 6;
	
	enqueue(e1);
	enqueue(e2);
	enqueue(e3);
	enqueue(e4);
	enqueue(e5);
	enqueue(e6);
	imprimeFila();

	if(!filaEstaVazia())
	{
		temp = dequeue();
		atende(temp);
	}
	imprimeFila();

	if(!filaEstaVazia())
	{
		temp = dequeue();
		atende(temp);
	}
	imprimeFila();

	enqueue(e6);
	imprimeFila();

	if(!filaEstaVazia())
	{
		temp = dequeue();
		atende(temp);
	}
	imprimeFila();

	if(!filaEstaVazia())
	{
		temp = dequeue();
		atende(temp);
	}
	imprimeFila();

	if(!filaEstaVazia())
	{
		temp = dequeue();
		atende(temp);
	}
	imprimeFila();

	scanf("%c", &c);
	return 0;
}

