#include "stdio.h"
#include "stdlib.h" /* NULL */

struct elemento
{
	int valor;

	struct elemento *proximo;
};

// Gerencia uma nova ligacao na lista
void listaEncadeadaLigacao(struct elemento *origem, struct elemento *destino)
{
	if(origem->proximo == NULL)
	{
		origem->proximo = destino;
		destino->proximo = NULL;
	}
	else
	{
		destino->proximo = origem->proximo;
		origem->proximo = destino;
	}
}

// Imprime a lista
void imprimeListaEncadeada(struct elemento *origem)
{
	printf("\n ");

	do
	{
		printf("%d ", origem->valor);
		origem = origem->proximo;
	} while(origem != NULL);
}

int main()
{
	char *c;

	struct elemento e1, e2, e3, e4, e5, e6;
	
	e1.valor = 1;
	e1.proximo = NULL;

	e2.valor = 2;
	e2.proximo = NULL;

	e3.valor = 3;
	e3.proximo = NULL;

	e4.valor = 4;
	e4.proximo = NULL;

	e5.valor = 5;
	e5.proximo = NULL;

	e6.valor = 6;
	e6.proximo = NULL;

	imprimeListaEncadeada(&e1);
	
	listaEncadeadaLigacao(&e1, &e2);
	listaEncadeadaLigacao(&e2, &e3);
	listaEncadeadaLigacao(&e3, &e4);
	listaEncadeadaLigacao(&e4, &e5);

	imprimeListaEncadeada(&e1);

	listaEncadeadaLigacao(&e3, &e6);

	imprimeListaEncadeada(&e1);




	scanf("%c", &c);
	return 0;
}

