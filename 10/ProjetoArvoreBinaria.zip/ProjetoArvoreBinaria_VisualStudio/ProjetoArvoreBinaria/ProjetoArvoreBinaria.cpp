#include "stdio.h"
#include "stdlib.h"

struct elemento
{
	int valor;

	struct elemento *no1;
	struct elemento *no2;
};

void imprimeArvore(struct elemento *no)
{
	printf("\n Imprimindo elemento %d.", no->valor);

	// Imprime os valores dos nos
	if(no->no1 != NULL)
		printf("\n O no #1 do elemento %d aponta para o elemento %d.", no->valor, (no->no1)->valor);

	if(no->no2 != NULL)
		printf("\n O no #2 do elemento %d aponta para o elemento %d.", no->valor, (no->no2)->valor);
	
	// Invoca recursivamente a impressao dos proximos nos
	if(no->no1 != NULL)
		imprimeArvore(no->no1);

	if(no->no2 != NULL)
		imprimeArvore(no->no2);
}

int main()
{
	char *c;

	struct elemento e1, e2, e3, e4, e5, e6;
	
	// Inicializa a arvore
	e1.valor = 1;
	e1.no1 = NULL;
	e1.no2 = NULL;

	e2.valor = 2;
	e2.no1 = NULL;
	e2.no2 = NULL;

	e3.valor = 3;
	e3.no1 = NULL;
	e3.no2 = NULL;

	e4.valor = 4;
	e4.no1 = NULL;
	e4.no2 = NULL;

	e5.valor = 5;
	e5.no1 = NULL;
	e5.no2 = NULL;

	e6.valor = 6;
	e6.no1 = NULL;
	e6.no2 = NULL;
	
	e1.no1 = &e2;
	e1.no2 = &e3;
	e3.no2 = &e4;
	e4.no1 = &e5;
	e4.no2 = &e6;

	imprimeArvore(&e1);

	scanf("%c", &c);
	return 0;
}

