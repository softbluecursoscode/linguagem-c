#include "stdio.h"

#define CAPACIDADE 5

struct elemento
{
	int valor;
};

struct elemento filaCircular[CAPACIDADE];

int indiceInsercao = 0;
int indiceRemocao = 0;
int numeroElementos = 0;

// Verifica se a fila esta vazia
int filaCircularEstaVazia()
{
	if(numeroElementos == 0)
		return 1;
	else
		return 0;
}

// Enfileira um elemento
void enqueueCircular(struct elemento e)
{
	if(numeroElementos >= CAPACIDADE)
	{
		printf("\n Estrutura de dados sem vaga para o elemento.");
	}
	else
	{
		filaCircular[indiceInsercao] = e;
		numeroElementos++;
		indiceInsercao++;

		if(indiceInsercao == CAPACIDADE)
			indiceInsercao = 0;
	}
}

// Desenfileira um elemento
struct elemento dequeueCircular()
{
	if(numeroElementos == 0)
		printf("\n Estrutura de dados vazia.");

	numeroElementos--;

	if(indiceRemocao == CAPACIDADE)
		indiceRemocao = 0;

	return filaCircular[indiceRemocao++];
}

// Imprime a fila
void imprimeFilaCircular()
{
	int x, y;

	if(numeroElementos == 0)
		printf("\n Estrutura de dados vazia.");

	printf("\n ");

	for(x=0; x<numeroElementos; x++)
	{
		y = indiceRemocao + x;

		if(y >= CAPACIDADE)
			y = y - CAPACIDADE;

		printf("%d ", filaCircular[y].valor);
	}
}

// Simula o atendimento de um elemento
void atende(struct elemento e)
{
	printf("\n Atendendo elemento %d.", e.valor);
}

int main()
{
	char *c;

	struct elemento e1, e2, e3, e4, e5, e6, temp;
	
	e1.valor = 1;
	e2.valor = 2;
	e3.valor = 3;
	e4.valor = 4;
	e5.valor = 5;
	e6.valor = 6;
	
	enqueueCircular(e1);
	enqueueCircular(e2);
	enqueueCircular(e3);
	enqueueCircular(e4);
	enqueueCircular(e5);
	enqueueCircular(e6);

	imprimeFilaCircular();

	if(!filaCircularEstaVazia())
	{
		temp = dequeueCircular();
		atende(temp);
	}
	imprimeFilaCircular();

	if(!filaCircularEstaVazia())
	{
		temp = dequeueCircular();
		atende(temp);
	}
	imprimeFilaCircular();

	enqueueCircular(e6);
	imprimeFilaCircular();

	if(!filaCircularEstaVazia())
	{
		temp = dequeueCircular();
		atende(temp);
	}
	imprimeFilaCircular();

	if(!filaCircularEstaVazia())
	{
		temp = dequeueCircular();
		atende(temp);
	}
	imprimeFilaCircular();

	if(!filaCircularEstaVazia())
	{
		temp = dequeueCircular();
		atende(temp);
	}
	imprimeFilaCircular();

	if(!filaCircularEstaVazia())
	{
		temp = dequeueCircular();
		atende(temp);
	}
	imprimeFilaCircular();

	scanf("%c", &c);
	return 0;
}

