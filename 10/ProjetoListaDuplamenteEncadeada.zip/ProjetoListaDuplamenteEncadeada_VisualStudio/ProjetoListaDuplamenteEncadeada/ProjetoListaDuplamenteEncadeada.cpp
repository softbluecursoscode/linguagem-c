#include "stdio.h"
#include "stdlib.h" /* NULL */

struct elemento
{
	int valor;

	struct elemento *anterior;
	struct elemento *proximo;
};

// Gerencia uma nova ligacao na lista 
void listaDuplamenteEncadeadaLigacao(struct elemento *origem, struct elemento *destino)
{
	if(origem->proximo == NULL)
	{
		origem->proximo = destino;
		destino->anterior = origem;
	}
	else
	{
		destino->proximo = origem->proximo;
		destino->anterior = origem;

		origem->proximo = destino;
		(destino->proximo)->anterior = destino;
	}
}

// Imprime a lista
void imprimeListaDuplamenteEncadeada(struct elemento *origem)
{
	printf("\n ");

	do
	{
		printf("%d ", origem->valor);
		origem = origem->proximo;
	} while(origem != NULL);
}

// Imprime a lista de tras para frente
void imprimeListaDuplamenteEncadeadaInvertido(struct elemento *ultimo)
{
	printf("\n ");

	do
	{
		printf("%d ", ultimo->valor);
		ultimo = ultimo->anterior;
	} while(ultimo != NULL);
}

int main()
{
	char *c;

	struct elemento e1, e2, e3, e4, e5, e6;
	
	e1.valor = 1;
	e1.anterior = NULL;
	e1.proximo = NULL;

	e2.valor = 2;
	e2.anterior = NULL;
	e2.proximo = NULL;

	e3.valor = 3;
	e3.anterior = NULL;
	e3.proximo = NULL;

	e4.valor = 4;
	e4.anterior = NULL;
	e4.proximo = NULL;

	e5.valor = 5;
	e5.anterior = NULL;
	e5.proximo = NULL;

	e6.valor = 6;
	e6.anterior = NULL;
	e6.proximo = NULL;

	imprimeListaDuplamenteEncadeada(&e1);
	
	listaDuplamenteEncadeadaLigacao(&e1, &e2);
	listaDuplamenteEncadeadaLigacao(&e2, &e3);
	listaDuplamenteEncadeadaLigacao(&e3, &e4);
	listaDuplamenteEncadeadaLigacao(&e4, &e5);
	
	imprimeListaDuplamenteEncadeada(&e1);
	imprimeListaDuplamenteEncadeadaInvertido(&e5);

	listaDuplamenteEncadeadaLigacao(&e3, &e6);

	imprimeListaDuplamenteEncadeada(&e1);
	imprimeListaDuplamenteEncadeadaInvertido(&e5);

	scanf("%c", &c);
	return 0;
}

