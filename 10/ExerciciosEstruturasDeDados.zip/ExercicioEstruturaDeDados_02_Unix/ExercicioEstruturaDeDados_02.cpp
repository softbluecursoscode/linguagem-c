#include "stdio.h"
#include "stdlib.h"	// Utilizada pela fun��o malloc

char *pilha;
int numeroDeElementos = 0;

void insereElementoNaPilha(char elemento)
{
	// Incrementa o n�mero de elementos
	numeroDeElementos++;	
	
	// Aloca mem�ria para a estrutura com o novo tamanho
	char *novaPilha = (char *) malloc (numeroDeElementos * sizeof(char));
	
	// Copia os elementos previamente existentes, caso hajam
	if(numeroDeElementos > 1)
	{
		int x;
		
		// Condi��o x<numeroDeElementos-1 � devido ao valor de numeroDeElementos j� ter sido incrementado. 
		// Para n�o acessar uma posi��o inexistente na pilha original (com 1 posi��o a menos) � necess�rio o -1.
		for(x=0; x<numeroDeElementos-1; x++)
		{
			novaPilha[x] = pilha[x];
		}
	}
	
	novaPilha[numeroDeElementos-1] = elemento;	// Adiciona o elemento no final da nova pilha alocada na mem�ria
	free(pilha);			// Limpa o ponteiro antigo da estrutura (tornou-se obsoleto)
	pilha = novaPilha;	// Altera o ponteiro da antiga estrutura para a nova
}

char removeElementoDaPilha()
{
	// Decrementa o n�mero de elementos
	numeroDeElementos--;	
	
	// Aloca mem�ria para a estrutura com o novo tamanho
	char *novaPilha = (char *) malloc (numeroDeElementos * sizeof(char));
	
	// Copia os elementos que ir�o permanecer na pilha (exceto o que ser� o removido)
	if(numeroDeElementos >= 1)
	{
		int x;
		
		// Condi��o x<numeroDeElementos � devido ao valor de numeroDeElementos j� ter sido decrementado. 
		// N�o � x<numeroDeElementos+1 pois a posi��o +1 � do elemento que est� sendo removido.
		for(x=0; x<numeroDeElementos; x++)
		{
			novaPilha[x] = pilha[x];	// Copia os elementos, j� organizando suas posi��es na nova estrutura
		}
	}
	
	char elementoRemovido = pilha[numeroDeElementos];	// Separa o elemento que est� sendo removido para retorn�-lo no final da fun��o
	free(pilha);				// Limpa o ponteiro antigo da estrutura (tornou-se obsoleto)
	pilha = novaPilha;			// Altera o ponteiro da antiga estrutura para a nova
	return elementoRemovido;	// Retorna o elemento removido
}

void visualizarPilha()
{
	int x;

	// Verifica se existem elementos para serem impressos
	if(numeroDeElementos == 0)
	{
		printf("A estrutura esta vazia.");
		return;
	}

	for(x=0; x<numeroDeElementos; x++) 
	{
		printf("%c ", pilha[x]);
	}
}

int main ()
{
	char opcao;
	char elemento;
	char limpezaDeBuffer;
	
	do
	{
		// Exibe o menu de op��es na tela
		printf("(i) Inserir elemento\n");
		printf("(r) Remover elemento\n");
		printf("(v) Visualizar elementos\n");
		printf("(s) Sair\n");
		printf("Digite sua opcao: ");
		scanf("%c", &opcao);
		scanf("%c", &limpezaDeBuffer);	// Limpeza do buffer de leitura
		
		switch(opcao)
		{
			case 'i':
				printf("Digite o elemento:");
				scanf("%c", &elemento);
				scanf("%c", &limpezaDeBuffer);	// Limpeza do buffer de leitura
				insereElementoNaPilha(elemento);
				break;
				
			case 'r':
				// Valida se existe algum elemento a ser removido
				if(numeroDeElementos == 0)
				{
					printf("A estrutura esta vazia.");
				}
				else
				{
					elemento = removeElementoDaPilha();
					printf("Elemento removido: %c", elemento);
				}
				break;
				
			case 'v':
				visualizarPilha();
				break;
				
			case 's':
				printf("Saindo do programa");
				break;
				
			default:
				printf("Opcao invalida.");
				break;
		}
		
		printf("\n\n\n");	// Pula algumas linhas para organizar a tela para o usu�rio ler novamente o menu
	
	} while (opcao != 's');	// Enquanto a op��o informada n�o for 's' o programa continua executando
	
	return 0;
}
