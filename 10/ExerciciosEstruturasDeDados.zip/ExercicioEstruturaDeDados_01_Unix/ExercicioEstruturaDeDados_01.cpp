#include "stdio.h"
#include "stdlib.h"	// Utilizada pela fun��o malloc

char *fila;
int numeroDeElementos = 0;

void insereElementoNaFila(char elemento)
{
	// Incrementa o n�mero de elementos
	numeroDeElementos++;	
	
	// Aloca mem�ria para a estrutura com o novo tamanho
	char *novaFila = (char *) malloc (numeroDeElementos * sizeof(char));
	
	// Copia os elementos previamente existentes, caso hajam
	if(numeroDeElementos > 1)
	{
		int x;
		
		// Condi��o x<numeroDeElementos-1 � devido ao valor de numeroDeElementos j� ter sido incrementado. 
		// Para n�o acessar uma posi��o inexistente na fila original (com 1 posi��o a menos) � necess�rio o -1.
		for(x=0; x<numeroDeElementos-1; x++)
		{
			novaFila[x] = fila[x];
		}
	}
	
	novaFila[numeroDeElementos-1] = elemento;	// Adiciona o elemento no final da nova fila alocada na mem�ria
	free(fila);			// Limpa o ponteiro antigo da estrutura (tornou-se obsoleto)
	fila = novaFila;	// Altera o ponteiro da antiga estrutura para a nova
}

char removeElementoDaFila()
{
	// Decrementa o n�mero de elementos
	numeroDeElementos--;	
	
	// Aloca mem�ria para a estrutura com o novo tamanho
	char *novaFila = (char *) malloc (numeroDeElementos * sizeof(char));
	
	// Copia os elementos que ir�o permanecer na fila (exceto o que ser� o removido)
	if(numeroDeElementos >= 1)
	{
		int x;
		
		// Condi��o x<numeroDeElementos+1 � devido ao valor de numeroDeElementos j� ter sido decrementado. 
		// Para acessar todos os valores da estrutura original, � necess�rio ent�o o +1.
		for(x=1; x<numeroDeElementos+1; x++)
		{
			novaFila[x-1] = fila[x];	// Copia os elementos, j� organizando suas posi��es na nova estrutura
		}
	}
	
	char elementoRemovido = fila[0];	// Separa o elemento que est� sendo removido para retorn�-lo no final da fun��o
	free(fila);					// Limpa o ponteiro antigo da estrutura (tornou-se obsoleto)
	fila = novaFila;			// Altera o ponteiro da antiga estrutura para a nova
	return elementoRemovido;	// Retorna o elemento removido
}

void visualizarFila()
{
	int x;

	// Verifica se ha elementos a serem impressos
	if(numeroDeElementos == 0)
	{
		printf("A estrutura esta vazia.");
		return;
	}

	for(x=0; x<numeroDeElementos; x++) 
	{
		printf("%c ", fila[x]);
	}
}

int main ()
{
	char opcao;
	char elemento;
	char limpezaDeBuffer;
	
	do
	{
		// Exibe o menu de op��es na tela
		printf("(i) Inserir elemento\n");
		printf("(r) Remover elemento\n");
		printf("(v) Visualizar elementos\n");
		printf("(s) Sair\n");
		printf("Digite sua opcao: ");
		scanf("%c", &opcao);
		scanf("%c", &limpezaDeBuffer);	// Limpeza do buffer de leitura
		
		switch(opcao)
		{
			case 'i':
				printf("Digite o elemento:");
				scanf("%c", &elemento);
				scanf("%c", &limpezaDeBuffer);	// Limpeza do buffer de leitura
				insereElementoNaFila(elemento);
				break;
				
			case 'r':
				// Valida se existe algum elemento a ser removido
				if(numeroDeElementos == 0)
				{
					printf("A estrutura esta vazia.");
				}
				else
				{
					elemento = removeElementoDaFila();
					printf("Elemento removido: %c", elemento);
				}
				break;
				
			case 'v':
				visualizarFila();
				break;
				
			case 's':
				printf("Saindo do programa");
				break;
				
			default:
				printf("Opcao invalida.");
				break;
		}
		
		printf("\n\n\n");	// Pula algumas linhas para organizar a tela para o usu�rio ler novamente o menu
	
	} while (opcao != 's');	// Enquanto a op��o informada n�o for 's' o programa continua executando
	
	return 0;
}

