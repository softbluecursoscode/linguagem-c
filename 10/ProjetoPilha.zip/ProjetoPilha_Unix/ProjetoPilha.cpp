#include "stdio.h"

#define CAPACIDADE 5

struct elemento
{
	int valor;
};

struct elemento pilha[CAPACIDADE];

int indiceInsercao = 0;

// Adiciona um elemento na pilha
void push(struct elemento e)
{
	if(indiceInsercao >= CAPACIDADE)
	{
		printf("\n Estrutura de dados sem vaga para o elemento.");
	}
	else
	{
		pilha[indiceInsercao] = e;
		indiceInsercao++;
	}
}

// Remove um elemento da pilha
struct elemento pop()
{
	if(indiceInsercao == 0)
		printf("\n Estrutura de dados vazia.");

	return pilha[--indiceInsercao];
}

// Imprime a pilha
void imprimePilha()
{
	int x;

	if(indiceInsercao == 0)
		printf("\n Estrutura de dados vazia.");
	else
	{
		printf("\n ");

		for(x=0; x<indiceInsercao; x++)
		{
			printf("%d ", pilha[x].valor);
		}
	}
}

// Verifica se a pilha esta vazia
int pilhaEstaVazia()
{
	if(indiceInsercao == 0)
		return 1;
	else
		return 0;
}

// Simula o atendimento a um elemento da pilha
void atende(struct elemento e)
{
	printf("\n Atendendo o elemento %d.", e.valor);
}

int main()
{
	char *c;

	struct elemento e1, e2, e3, e4, e5, e6, temp;
	
	e1.valor = 1;
	e2.valor = 2;
	e3.valor = 3;
	e4.valor = 4;
	e5.valor = 5;
	e6.valor = 6;
	
	push(e1);
	push(e2);
	push(e3);
	push(e4);
	push(e5);
	push(e6);
	imprimePilha();

	if(!pilhaEstaVazia())
	{
		temp = pop();
		atende(temp);
	}
	imprimePilha();

	if(!pilhaEstaVazia())
	{
		temp = pop();
		atende(temp);
	}
	imprimePilha();

	push(e6);
	imprimePilha();

	if(!pilhaEstaVazia())
	{
		temp = pop();
		atende(temp);
	}
	imprimePilha();

	if(!pilhaEstaVazia())
	{
		temp = pop();
		atende(temp);
	}
	imprimePilha();

	if(!pilhaEstaVazia())
	{
		temp = pop();
		atende(temp);
	}
	imprimePilha();

	if(!pilhaEstaVazia())
	{
		temp = pop();
		atende(temp);
	}
	imprimePilha();

	scanf("%c", &c);
	return 0;
}

