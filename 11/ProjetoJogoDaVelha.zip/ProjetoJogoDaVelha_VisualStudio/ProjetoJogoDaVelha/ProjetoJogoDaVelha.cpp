#include "stdio.h"      // printf, scanf
#include "stdlib.h"     // srand, rand, exit, EXIT_SUCCESS, EXIT_FAILURE
#include "time.h"       // time

#define MARCADOR_VAZIO 32	// Espaco em branco
#define MARCADOR_X 88		// Marcador X (Ascii)
#define MARCADOR_O 79		// Marcador O (Ascii)

#define SIM 1	// Verdadeiro
#define NAO 0	// Falso

short int tabuleiro[3][3];	// Tabuleiro do jogo
short int vencedor;			// Armazena o vencedor
short int posLinha = 0;		// Captura a posicao de linha que o usuario deseja jogar
short int posColuna = 0;	// Captura a posicao de coluna que o usuario deseja jogar

// ===================================
// Imprime o tabuleiro do jogo na tela
// ===================================
void imprimeTabuleiro()
{
	short int linha = 0;	// Variavel auxiliar de lacos de repeticao

	printf("\n\n");			// Pula algumas linhas para separar do tabuleiro anterior

	for(linha=0; linha<3; linha++)
	{
		// Imprime os 3 elementos da linha
		printf("\n  %c | %c | %c ", tabuleiro[linha][0], tabuleiro[linha][1], tabuleiro[linha][2]);

		// Para separar cada linha do tabuleiro utiliza uma linha de tra�os
		if(linha < 2)
		{
			printf("\n -----------");
		}
	}
}

// ====================================================================
// Antes de cada jogo esta fun��o limpa o tabuleiro e variaveis do jogo
// ====================================================================
void limpaTabuleiro()
{
	short int linha = 0;		// Variavel auxiliar de lacos de repeticao
	short int coluna = 0;		// Variavel auxiliar de lacos de repeticao

	vencedor = MARCADOR_VAZIO;	// Limpa a variavel que armazena o vencedor do jogo

	// Limpa todas as posicoes do tabuleiro
	for(linha=0; linha<3; linha++)
	{
		for(coluna=0; coluna<3; coluna++)
		{
			tabuleiro[linha][coluna] = MARCADOR_VAZIO;
		}
	}
}

// ===============================
// Realiza uma jogada no tabuleiro
// ===============================
int jogar(int simbolo, int linha, int coluna)
{
	// simbolo: indica qual jogador esta efetuando a jogada
	// linha: indica em qual linha a jogada deve ser realizada
	// coluna: indica em qual coluna a jogada deve ser realizada

	// Verifica se a posicao em questao esta disponivel
	if(tabuleiro[linha][coluna] != MARCADOR_VAZIO)
	{
		// Se nao estiver, retorna indicando que a jogada nao foi realizada
		return NAO;
	}

	// Se chegar neste ponto a jogada pode ser realizada
	tabuleiro[linha][coluna] = simbolo;

	// Retorna sucesso da operacao
	return SIM;
}

// ==========================================
// Realiza a estrategia de jogo do computador
// ==========================================
void computadorJogar()
{
	short int linha = 0;			// Variavel auxiliar de lacos de repeticao
	short int coluna = 0;			// Variavel auxiliar de lacos de repeticao
	short int casasMinhas = 0;		// Para cada linha/coluna/diagonal contabiliza quantas posicoes sao do computador
	short int casasVazias = 0;		// Para cada linha/coluna/diagonal contabiliza quantas posicoes estao disponiveis
	short int jogadaRandomica = 0;	// Variavel auxiliar para randomizacao de jogada

	// Verifica por uma linha que falte 1 para vencer
	// ----------------------------------------------
	for(linha=0; linha<3; linha++)
	{
		casasMinhas = 0;
		casasVazias = 0;

		// Procura pela linha em cada coluna
		for(coluna=0; coluna<3; coluna++)
		{
			if(tabuleiro[linha][coluna] == MARCADOR_O)
				casasMinhas++;
			else if(tabuleiro[linha][coluna] == MARCADOR_VAZIO)
				casasVazias++;
		}

		// Joga na linha vencedora (se houver)
		if(casasMinhas == 2 & casasVazias == 1)
		{
			for(coluna=0; coluna<3; coluna++)
			{
				if(tabuleiro[linha][coluna] == MARCADOR_VAZIO)
				{
					jogar(MARCADOR_O, linha, coluna);
					return;
				}
			}
		}
	}

	// Verifica por uma coluna que falte 1 para vencer
	// -----------------------------------------------
	for(coluna=0; coluna<3; coluna++)
	{
		casasMinhas = 0;
		casasVazias = 0;

		// Procura pela coluna em cada linha
		for(linha=0; linha<3; linha++)
		{
			if(tabuleiro[linha][coluna] == MARCADOR_O)
				casasMinhas++;
			else if(tabuleiro[linha][coluna] == MARCADOR_VAZIO)
				casasVazias++;
		}

		// Joga na coluna vencedora (se houver)
		if(casasMinhas == 2 & casasVazias == 1)
		{
			for(coluna=0; coluna<3; coluna++)
			{
				if(tabuleiro[linha][coluna] == MARCADOR_VAZIO)
				{
					jogar(MARCADOR_O, linha, coluna);
					return;
				}
			}
		}
	}

	// Verifica por uma diagonal (#1) que falte 1 para vencer
	// ------------------------------------------------------
	casasMinhas = 0;
	casasVazias = 0;

	// Comando 'for' especial, gerenciando duas variaveis
	for(coluna=0, linha=0; coluna<3; coluna++, linha++)
	{
		// Procura pela diagonal
		if(tabuleiro[linha][coluna] == MARCADOR_O)
			casasMinhas++;
		else if(tabuleiro[linha][coluna] == MARCADOR_VAZIO)
			casasVazias++;
	}

	// Joga na diagonal (#1) vencedora (se houver)
	if(casasMinhas == 2 & casasVazias == 1)
	{
		for(coluna=0, linha=0; coluna<3; coluna++, linha++)
		{
			if(tabuleiro[linha][coluna] == MARCADOR_VAZIO)
			{
				jogar(MARCADOR_O, linha, coluna);
				return;
			}
		}
	}

	// Verifica por uma diagonal (#2) que falte 1 para vencer
	// ------------------------------------------------------
	casasMinhas = 0;
	casasVazias = 0;

	// Comando 'for' especial, gerenciando duas variaveis
	for(coluna=0, linha=2; coluna<3; coluna++, linha--)
	{
		// Procura pela diagonal
		if(tabuleiro[linha][coluna] == MARCADOR_O)
			casasMinhas++;
		else if(tabuleiro[linha][coluna] == MARCADOR_VAZIO)
			casasVazias++;
	}

	// Joga na diagonal (#2) vencedora (se houver)
	if(casasMinhas == 2 & casasVazias == 1)
	{
		for(coluna=0, linha=2; coluna<3; coluna++, linha--)
		{
			if(tabuleiro[linha][coluna] == MARCADOR_VAZIO)
			{
				jogar(MARCADOR_O, linha, coluna);
				return;
			}
		}
	}

	// TODO: Jogadas que impecam o adversario a ganhar na proxima rodada
	// TODO: Estrategias avancadas de jogo

	// Realiza uma jogada randomica, sem inteligencia embutida
	// Conta quantas casas vazias existem (quantas jogadas podem ser feitas)
	casasVazias = 0;

	for(linha=0; linha<3; linha++)	
	{
		for(coluna=0; coluna<3; coluna++)
		{
			if(tabuleiro[linha][coluna] == MARCADOR_VAZIO)
			{
				casasVazias++;
			}
		}
	}
	  
	// Randomiza a semente geradora de numeros aleatorios
	srand(time(NULL));

	// Randomiza um numero entre 0 e o numero de jogadas possiveis
	jogadaRandomica =  rand() % casasVazias;

	// Avanca ate a posicao escolhida randomicamente, e joga ao encontra-la
	casasVazias = 0;
	for(linha=0; linha<3; linha++)
	{
		for(coluna=0; coluna<3; coluna++)
		{
			if(tabuleiro[linha][coluna] == MARCADOR_VAZIO)
			{
				if(casasVazias == jogadaRandomica)
				{
					jogar(MARCADOR_O, linha, coluna);
					return;
				}
				else
					casasVazias++;
			}
		}
	}
}

// ==============================================================
// Verifica se o jogo encerrou, marcando o vencedor se for o caso
// ==============================================================
int verificarResultado()
{
	short int linha = 0;	// Variavel auxiliar de lacos de repeticao
	short int coluna = 0;	// Variavel auxiliar de lacos de repeticao

	// Procura por uma linha vencedora
	for(linha=0; linha<3; linha++)
	{
		if(tabuleiro[linha][0] == tabuleiro[linha][1] 
			&& tabuleiro[linha][1] == tabuleiro[linha][2] 
			&& tabuleiro[linha][2] != MARCADOR_VAZIO)
		{
			vencedor = tabuleiro[linha][0];
			return SIM;
		}
	}

	// Procura por uma coluna vencedora
	for(coluna=0; coluna<3; coluna++)
	{
		if(tabuleiro[0][coluna] == tabuleiro[1][coluna] 
			&& tabuleiro[1][coluna] == tabuleiro[2][coluna] 
			&& tabuleiro[2][coluna] != MARCADOR_VAZIO)
		{
			vencedor = tabuleiro[0][coluna];
			return SIM;
		}
	}

	// Procura por uma diagonal vencedora (#1)
	if(tabuleiro[0][0] == tabuleiro[1][1] 
		&& tabuleiro[1][1] == tabuleiro[2][2] 
		&& tabuleiro[2][2] != MARCADOR_VAZIO)
	{
		vencedor = tabuleiro[0][0];
		return SIM;
	}

	// Procura por uma diagonal vencedora (#2)
	if(tabuleiro[2][0] == tabuleiro[1][1] 
		&& tabuleiro[1][1] == tabuleiro[0][2] 
		&& tabuleiro[0][2] != MARCADOR_VAZIO)
	{
		vencedor = tabuleiro[2][0];
		return SIM;
	}

	// Verifica se o jogo terminou empatado:
	// Se nao foi encontrada nenhuma linha/coluna/diagonal vencedora e ainda existir
	// posicoes jogaveis, o jogo continua
	for(linha=0; linha<3; linha++)
	{
		for(coluna=0; coluna<3; coluna++)
		{
			if(tabuleiro[linha][coluna] == MARCADOR_VAZIO)
			{
				return NAO;
			}
		}
	}

	// Se nenhuma linha/coluna/diagonal vencedora for encontrada,
	// e nao houver mais posicoes para jogo, retorna que o jogo encerrou
	// sem alterar a variavel global 'vencedor'
	return SIM;	
}

// ======================================================
// Gerencia o jogo, alternando entre usuario e computador
// ======================================================
void jogo(int quemJoga)
{
	short int jogou = 0;	// Variavel auxiliar para controlar se o usuario jogou com sucesso

	limpaTabuleiro();		// Reseta o tabuleiro antes de cada jogo

	// Enquanto o jogo nao terminar...
	do
	{
		// Imprime o tabuleiro na tela
		imprimeTabuleiro();

		// Se for a vez do computador jogar...
		if(quemJoga == MARCADOR_O)
		{
			computadorJogar();		// Computador joga
			quemJoga = MARCADOR_X;	// Passa a vez para o proximo jogador
		}

		// Se for a vez do usuario jogar...
		else
		{
			// Enquanto uma jogada valida nao aparecer, repita a leitura do usuario...
			do
			{
				// Controla o sucesso da jogada do usuario (posicao valida de jogo)
				jogou = NAO;

				// Obtem do usuario a linha e a coluna de sua jogada
				printf("\n Informe a linha de sua jogada (0, 1 ou 2): ");
				scanf("%d", &posLinha);
				printf("\n Informe a coluna de sua jogada (0, 1 ou 2): ");
				scanf("%d", &posColuna);

				// Verifica se as posicoes estao entre 0 e 2, 
				if(posLinha >= 0 & posLinha <=2 & posColuna >=0 & posColuna <= 2)
				{
					// Verifica se a jogada foi realizada com sucesso (posicao ocupada)
					if( jogar(MARCADOR_X, posLinha, posColuna) == SIM)
					{
						jogou = SIM;			// Jogada realizada com sucesso
						quemJoga = MARCADOR_O;	// Passa a vez para o computador jogar
					}
					else
					{
						// Informa que a posicao indicada ja esta ocupada
						printf("\n Posicao ocupada.");
					}
				}

				// Informa na tela que a posicao da jogada e invalida
				else
				{
					printf("\n Jogada invalida, tente novamente.");
				}

			} while(jogou == NAO);			// Controle de jogada do usuario
		}
	} while(verificarResultado() == NAO);	// Controle de fim de jogo

	// Ao sair do laco de repeticao, indica que o jogo acabou

	// Imprime o tabuleiro final na tela
	imprimeTabuleiro();

	// Informa o vencedor
	printf("\n Jogo finalizado. ");

	switch(vencedor)
	{
		case MARCADOR_VAZIO:
			printf("Empate.");
			break;
		case MARCADOR_X:
			printf("Parabens, voce venceu.");
			break;
		case MARCADOR_O:
			printf("O computador venceu.");
			break;
	}

	return;
}

// ===========================
// Funcao inicial da aplicacao
// ===========================
int main()
{
	short int opcao=0;
	short int subopcao=0;
	short int vezJogador=0;

	// Enquanto o usuario nao informar que deseja sair da aplicacao...
	do
	{
		// Apresenta o menu da aplicacao
		printf("\n\n 1) Jogar");
		printf("\n 2) Sair\n ");
		scanf("%d", &opcao);

		// Se a opcao for a de jogar...
		if(opcao == 1)
		{
			// Enquanto o usuario nao informar corretamente quem comeca...
			do
			{
				// Apresenta o menu de quem deve comecar o jogo
				printf("\n\n 1) Usuario comeca");
				printf("\n 2) Computador comeca\n ");
				scanf("%d", &subopcao);

				// Se a opcao informada for invalida, exibe um aviso na tela
				if(subopcao != 1 & subopcao != 2)
				{
					printf("\n Opcao invalida.");
				}

			} while(subopcao != 1 & subopcao != 2);

			// Assim que uma opcao valida de quem comeca o jogo for informada o jogo comeca
			if(subopcao == 1)
			{
				jogo(MARCADOR_X);	// Usuario comeca
			}
			else
			{
				jogo(MARCADOR_O);	// Computador comeca
			}

			// Apos o final do jogo, a aplicacao retorna para este ponto para uma
			// nova leitura do menu inicial sobre jogar ou sair
		}

		// Encerra a aplicacao caso o usuario solicite
		else if(opcao == 2)
		{
			// Encerra adequadamente a aplicacao
			exit(EXIT_SUCCESS);
		}

		// Exibe um aviso de opcai invalida para o menu inicial
		else
		{
			printf("\n Opcao invalida.");
		}

	} while(opcao != 2);

	// Encerra de forma problematica (codigo inatingivel)
	exit(EXIT_FAILURE);

	// Formaliza o retorno da funcao main
	return 0;
}
